#include <iostream>
#include <math.h>
#include <stdlib.h>
#include <netcdfcpp.h>
#include <fstream>
#include <vector>
#include <map>
#include <string>
#include <gsm.h>
using namespace std;


//float lon0 = 60.25, lonf =  100.25, lat0 = 7.25, latf = 38.25, dx = 0.5, dy = 0.5, dt0 = 1, dlev = 1;
int nlons, nlats, nlevs = 1;
string basedate;
string 	ipfile_grid, 
		ipfile_pre, ipfile_tmp, ipfile_cld,
		opfile_grid, opfile_soil,
		opfile_tmp, opfile_pre, opfile_cld;
string varname, varunits;
int ts;
int nyrs, nmonths, baseyr;

class iCoord{
public:
	short lon;
	short lat;
};

class Coord{
public:
	float lon;
	float lat;
	Coord(){};
	Coord(float xlon, float xlat){lon = xlon; lat = xlat;};
};

class ClimateHeader{
public: 
	int order, firstyear, nyear, ncell;
};
 

int writeHeader(ofstream &fout, string header, int version){
	fout.write(header.c_str(), header.size());
	if (fout.bad()) cout << "WRITE ERROR IN HEADER\n"; 
	fout.write((char*)&version, sizeof(version));
	if (fout.bad()) cout << "WRITE ERROR IN VERSION\n"; 
}

int writeClimateHeader(ofstream &fout, string climheader, int ngrids){

	fout.write(climheader.c_str(), climheader.size());	
	int version =1;
	fout.write((char*)&version, sizeof(version));	
	if (fout.bad()) cout << "WRITE ERROR IN CLIMATE HEADER\n";
	
	ClimateHeader mch;
	mch.order = 1;
    mch.firstyear = baseyr;  
	mch.nyear = nyrs;
	mch.ncell = ngrids;
	fout.write( (char*)&mch, sizeof(mch) );
	if (fout.bad()) cout << "WRITE ERROR IN MCH\n";

}

int writeCoord_bin(ofstream &fout, Coord c){
	iCoord ic;
	ic.lon = short(c.lon*100);
	ic.lat = short(c.lat*100);
	fout.write((char*)&ic, sizeof(ic));
	//cout << "coord = (" << ic.lon << ", " << ic.lat << ")\n";   
	if (fout.bad()) cout << "WRITE ERROR\n"; 
	return 0; 
}

int writeRecord(ofstream &fout, gVar varray[], vector <Coord> coords, string vname){
	// get value for coords listed in vector and write to file 
	for (int i = 0; i < coords.size(); ++i){
		for (int m=0; m<12; ++m){
			//cout << "(i,m) = (" << i << ", " << m << ")\n";
			float f = varray[m].getValue(coords[i].lon, coords[i].lat);
			short s;
			if (vname == "ts"){
				s = short(f);
			    s=short(f*10);  //LPJ needs temp file in DegC and in int format.So multiply by 10
			     //cout << "(i) = (" << i << ") = " << vname << " = "<< f<<"\n";
			    }
			else if (vname == "pr") {
					s = short(f);
			     s = short(f*30);  //LPJ needs prec file in mm/month units.So multiply by 30 if it's mm/day.
			     //cout << "(i) = (" << i << ") = " << vname <<  " = "<< f<<"\n";
			     }
			else if (vname == "clt"){
				 s = short(f);    //LPJ needs clt in %.
				 //cout << "(i) = (" << i << ") = " << vname << " = "<< f<<"\n";
				 }
			else {(cout << "FATAL ERROR: wrong variable name!\n");}
	
			fout.write((char*)&s, sizeof(s));
			}
	}
	return 0;
}

int init(){
	int i; string s, t;
	ifstream fin; fin.open("nc2bin_ip.txt");
	fin >> t >> t >> s; getline(fin, t, '\n'); ipfile_grid = s;
	

	fin >> t >> t >> s; getline(fin, t, '\n'); ipfile_tmp = s;
	fin >> t >> t >> s; getline(fin, t, '\n'); ipfile_pre = s;
	fin >> t >> t >> s; getline(fin, t, '\n'); ipfile_cld = s;

	fin >> t >> t >> s; getline(fin, t, '\n'); opfile_grid = s;
	fin >> t >> t >> s; getline(fin, t, '\n'); opfile_soil = s;

	fin >> t >> t >> s; getline(fin, t, '\n'); opfile_tmp = s;
	fin >> t >> t >> s; getline(fin, t, '\n'); opfile_pre = s;
	fin >> t >> t >> s; getline(fin, t, '\n'); opfile_cld = s;

	fin >> t >> t >> i; getline(fin, t, '\n'); nyrs = i; nmonths = i*12;
	fin >> t >> t >> i; getline(fin, t, '\n'); baseyr = i;

//	fin >> t >> t >> s; getline(fin, t, '\n'); varname = s;

	fin.close();
	cout << "INIT Done." << '\n';
	cout << "nyrs = " << nyrs << ", nmonths = " << nmonths << '\n';
	
}


int checkNyrs(gVar &v){
	cout << "Varname =  (" << v.varname << ")\n";
	if (v.ntimes > 12 && nmonths > v.ntimes) cout << "WARNING: Values will be recycled after " << v.ntimes << " months\n"; // printed for climatology run
	else if (v.ntimes == nmonths) cout << "Values will be written only once for " << v.ntimes << " months\n";  //printed for continuous run
	else if (v.ntimes == 12) cout <<  "Values will be recycled per year.\n";   //printed only for one year run
	else { cout << "ERROR: Unknown combination :P\n"; }
}

const float glimits_globe[4] = {0, 360, -90, 90};

int main(){

	//const float glimits_custom[4] = {lon0, lonf, lat0, latf};
	init();
	
	// set NETCDF error behavior to non-fatal
	NcError err(NcError::silent_nonfatal);

	ofstream gsml("gsm_log.txt");
	gsm_log = &gsml;

	// input nc-files
	gVar pre, tmp, cld;  
	     
	NcFile_handle pre_handle, tmp_handle, cld_handle;
	
	tmp_handle.open(ipfile_tmp, "r", glimits_globe);
	tmp_handle.readCoords(tmp);
	int tmp_id = tmp_handle.getVarID("tas");
	tmp_handle.readVarAtts(tmp, tmp_id);


	pre_handle.open(ipfile_pre, "r", glimits_globe);
	pre_handle.readCoords(pre);
	int pre_id = pre_handle.getVarID("pr");
	pre_handle.readVarAtts(pre, pre_id);

	
	cld_handle.open(ipfile_cld, "r", glimits_globe);
	cld_handle.readCoords(cld);
	int cld_id = cld_handle.getVarID("clt");
	cld_handle.readVarAtts(cld, cld_id);

	pre.printGrid();
	tmp.printGrid();
	cld.printGrid();

	// output grid and soil files
	ofstream fout_grid; fout_grid.open(opfile_grid.c_str(), ios::out | ios::binary);
	ofstream fout_soil; fout_soil.open(opfile_soil.c_str(), ios::out | ios::binary);

	// output bin files (climate vars)
	ofstream fout_tmp; fout_tmp.open(opfile_tmp.c_str(), ios::out | ios::binary);
	ofstream fout_pre; fout_pre.open(opfile_pre.c_str(), ios::out | ios::binary);
	ofstream fout_cld; fout_cld.open(opfile_cld.c_str(), ios::out | ios::binary);
	
	// input text file listing grid points and soil
	ifstream fin_grid; fin_grid.open(ipfile_grid.c_str());	

	const bool grid_only = false;
	// -------- GRID FILES ---------------------------

	// 1. Write header
	writeHeader(fout_grid, "LPJGRID", 1);

	// write grid and soil bin files
	vector <Coord> coords;
	vector <int> soil_vals;
	int n; float xlat, xlon, soilval; 
	int iter=1;
	while (1){
		fin_grid >> n; 
		if (fin_grid.eof()) break;
		//cout << "iter = " << iter << ", ";
		fin_grid >> xlat >> xlon >> soilval; 
		Coord c(xlon, xlat); 
		//cout << "c = (" << c.lon << ", " << c.lat << ")\n";
		coords.push_back(c);
		soil_vals.push_back(soilval);
		++iter;
	}
	int ngrids = coords.size();
	cout << "ngrids = " << ngrids << '\n';
	
	// 2. write number of grids
	fout_grid.write((char*)&ngrids, sizeof(ngrids));

	// 3. write soil type and coords
	for (int i=0; i<=ngrids; ++i){
		Coord c = coords[i];
		char soilval_char = char(soil_vals[i]);
		writeCoord_bin(fout_grid, c);
		fout_soil.write((char*)&soilval_char, sizeof(soilval_char));
	}
	
	fout_soil.flush(); fout_soil.close();
	fout_grid.flush(); fout_grid.close();
	cout << "Finished writing grid files\n\n"; 
		
	if (grid_only) return 0;
	
	// -------------- CLIMATE FILES ----------------
	
	// 0. Check is input is consistent
	checkNyrs(pre);
	checkNyrs(tmp);
	checkNyrs(cld);
	
	// 1. write header
	writeClimateHeader(fout_pre, "LPJCLIMATE", ngrids);
	writeClimateHeader(fout_tmp, "LPJCLIMATE", ngrids);
	writeClimateHeader(fout_cld, "LPJCLIMATE", ngrids);
	
	// 2. Read 1 yr's data
	gVar yrData[12]; 
	for (int m=0; m<12;++m) yrData[m] = tmp;
	
	
	// 2. write data
	for (int t=0; t < nyrs; ++t){
		// read values for 12 months
		/*for (int i = 0; i < 12; ++i){
			tmp_handle.readVar(yrData[i], (t*12+i)%tmp.ntimes, tmp_id);
			pre_handle.readVar(yrData[i], (t*12+i)%pre.ntimes, pre_id);
			cld_handle.readVar(yrData[i], (t*12+i)%cld.ntimes, cld_id);
		}
		*/
		//cout << "step = " << t << " Read values\n";
		// write bin
		for (int i = 0; i < 12; ++i){
		tmp_handle.readVar(yrData[i], (t*12+i)%tmp.ntimes, tmp_id);
		}
		//int n;
		writeRecord(fout_tmp, yrData, coords, "ts");
		
		for (int i = 0; i < 12; ++i){
		pre_handle.readVar(yrData[i], (t*12+i)%pre.ntimes, pre_id);
		}
		//int m;
		writeRecord(fout_pre, yrData, coords, "pr");
		
		for (int i = 0; i < 12; ++i){
		cld_handle.readVar(yrData[i], (t*12+i)%cld.ntimes, cld_id);
		}
		//int o;
		writeRecord(fout_cld, yrData, coords, "clt");

		if (t %10 == 0){
			cout << "step = " << t << "\t| t_tmp = " << t%tmp.ntimes <<"\t| t_pre = " << t%pre.ntimes <<"\t| t_cld = " << t%cld.ntimes << '\n' ;
			
		}
	}
	fout_tmp.flush();
	fout_tmp.close();
	fout_pre.flush();
	fout_pre.close();
	fout_cld.flush();
	fout_cld.close();

	cout << "> Successfully wrote BIN file!!\n";

}


