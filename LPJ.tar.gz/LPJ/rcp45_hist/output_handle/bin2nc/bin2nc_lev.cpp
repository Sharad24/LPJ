#include <iostream>
#include <math.h>
#include <netcdfcpp.h>
//#include <netcdfcpp.h>
#include <fstream>
#include <vector>
#include <map>
using namespace std;

//#include "/usr/local/lib/netcdf/include/gsm.h"
#include <gsm.h>

float lon0 = 60.25, lonf =  100.25, lat0 = 6.25, latf = 38.25, dx = 0.5, dy = 0.5, dt0 = 1, dlev = 1;
int nlons, nlats, nlevs = 1;
string basedate;
string gridfile, ipfile, opfile;
string varname, varunits;
int ts;

class iCoord{
public:
	short lon;
	short lat;
};

class Coord{
public:
	float lon;
	float lat;
	Coord(){};
	Coord(float xlon, float xlat){lon = xlon; lat = xlat;};
};

Coord readCoord_bin(ifstream &fin){
	iCoord c;
	fin.read((char*)&c, sizeof(c));
	if (fin.eof() || fin.fail() ){
		return Coord(-999,-999);
	}
	return Coord(float(c.lon)*0.01, float(c.lat)*0.01); 
}

int readRecord(ifstream &fin, vector <Coord> &coords, gVar &v){
	// read data for 1 time step
	for (int i=0; i < coords.size(); ++i){
		// deal with CLM's stupidity. skip header.
		if (nlevs > 1){
			int b;
			fin.read((char*)&b, sizeof(b));
		}
//		else{
//			CERR << "FATAL: num stands != 1!! exiting\n";
//			return 1;
//		}
		for (int ilev=0; ilev<nlevs; ++ilev){
			float a;
			fin.read((char*)&a, sizeof(a));
			
			int ilat = (coords[i].lat - lat0)/dy;
			int ilon = (coords[i].lon - lon0)/dx;
			
			v(ilon, ilat, ilev) = a;
		}
		// cout << "lon= " << coords[i].lon << ", lat = " << coords[i].lat << ": " << a << '\n';
		if (fin.eof() || fin.fail()) break; 
	}
	return 0;
}

int init(){
	int i; string s, t;
	ifstream fin; fin.open("bin2nc_ip.txt");
	fin >> t >> t >> i; getline(fin, t, '\n'); nlevs = i;
	fin >> t >> t >> s; getline(fin, t, '\n'); ts = (s == "year")? 12:1;
	fin >> t >> t >> s; getline(fin, t, '\n'); gridfile = s;
	fin >> t >> t >> s; getline(fin, t, '\n'); ipfile = s;
	fin >> t >> t >> s; getline(fin, t, '\n'); opfile = s;
	fin >> t >> t >> s; getline(fin, t, '\n'); basedate = s;
	fin >> t >> t >> s; getline(fin, t, '\n'); varname = s;
	fin >> t >> t >> s; getline(fin, t, '\n'); varunits = s;
	fin.close();
	
}


int main(){

	const float glimits_globe[4] = {0, 360, -90, 90};
	init();
	
	// set NETCDF error behavior to non-fatal
	NcError err(NcError::silent_nonfatal);

	vector <float> lons = createCoord(lon0, lonf, dx, nlons);
	vector <float> lats = createCoord(lat0, latf, dy, nlats);
	vector <double> times;
	vector <float> levs(nlevs,0);
	for (int i=0; i< nlevs; ++i) levs[i] = i;

	ofstream gsml("gsm_log.txt");
	gsm_log = &gsml;

	ifstream fin; fin.open(gridfile.c_str(), ios::in | ios::binary);
	if (!fin) cout << "Error opening file\n";
	
	vector <Coord> coords;
	while(1){
		Coord c = readCoord_bin(fin);
		if (c.lon == -999) break;
		coords.push_back(c); 
	}
	for (int i=0; i<coords.size(); ++i) cout << coords[i].lon << " " << coords[i].lat << endl;

	fin.close();

	fin.open(ipfile.c_str(), ios::in | ios::binary);

	vector <double> t1(1512/ts,0);	// dummy time vector
	for (int i=0; i<t1.size(); ++i) t1[i] = i*ts;
	gVar veg(varname, varunits, "months since " + basedate);       
	veg.setCoords(t1, levs, lats, lons);
	veg.printGrid();
	veg.values.resize(nlons*nlats*nlevs, std_missing_value);
	veg.missing_value = std_missing_value;
	
	NcFile_handle veg_handle;
	veg_handle.open(opfile, "w", glimits_globe);
	veg_handle.writeCoords(veg);
	veg_handle.writeTimeValues(veg);
	NcVar* vVar = veg_handle.createVar(veg);

	int t = 0;
	while (1){
		//read data
		int n = readRecord(fin, coords, veg);
		if (n==1) continue; 
		
		if (fin.eof()) {
			cout << "EOF detected!\n";
			break; 
		}	
		if (fin.fail()) {
			cout << "FAIL bit detected!\n";
			break; 
		}	
		
		// write to NC file
		veg_handle.writeVar(veg, vVar, t);
		times.push_back(t*ts);
		++t;
		cout << "step = " << t << '\n';
	}

//	veg.ntimes = times.size(); veg.times = times;
//	veg_handle.writeTimeValues(veg);
	cout << times.size() << endl;
	
	veg_handle.close();
	
	cout << "> Successfully wrote NC file!!\n";


}


