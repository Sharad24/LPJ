﻿

Data required:

	Climate data: variables - cloud cover (%), precipitation (mm/month) and temperature (degree C) 
	(bias-corrected with CRU-TS-4.01 and truncated for respective time periods)
	
	CO2 concentrations: constant or varying file
	
	Grid: coords_list.txt (grid and soil information) - Soil data and associated README can be found in folder generate_grid/


Tools required:

	Netcdf (c and cxx-legacy), hdf4 and hadf5 packages, slib and zlib packages

	LibGSM library (Release 2.0) (https://github.com/jaideep777/Flare/releases/tag/v2.0)
	
	Climate Data Operators (CDO)
	

Scenarios: Spin-up (1176-1975), RCP 4.5 (1976-2099) and RCP 8.5 (1976-2099)


STEP 0: Generate your coords_list.txt following the sample and README in generate_grid

	
LPJ is divided into three steps:
		
STEP 1: Input_handle, converts the netcdf files to clm format, soil and grid files to binary format (input)
	 
	Make changes in the following files as mentioned below:
			
			1. Input folder: input climate data 
	
			2. nc2bin_lev.cpp: change variable name according to the variable name in the input files
	
			3. nc2bin_ip.txt: specify input file names (as in the input folder) and the base-year
	
			4. coords_list.txt : paste the appropriate coords_list.txt
	
			5. Makefile : change libGSM path (and version) and NetCDF path according to location

		
			6. Go to the Terminal and DO: make clean

				  			   			  make
		
				  		                 ./nc2bin_lev
			
			7. Output folder: copy paste the output files created in this folder into the input folder of LPJ_run (STEP 2)


STEP 2: Running LPJ 

Spin-up :500 years; Total 800 years i.e. 1176-1976
Historical and RCP Projection Runs: 1976-2100

	Make changes in the following files as mentioned below:
	
			1. Input folder: copy paste the output files from output folder of input_handle (STEP 1) and CO2 concentrations (constant/ varying) 

			2. lpj.conf: specify grid cell (first and last) according to the coords_list.txt; set spin-up years to 500;
			select the first year of simulation (1676), add 300 years to it to calculate the last year of simulation(1976)	
				
			3. model.conf: specify input file names	
	
			4. Go to the Terminal and DO: sh configure.sh
	
				 						  make clean

				                          make
			
				                          ./lpj

	    	5. Test folder: copy paste the output files created into the input folder of the output_handle (STEP 3)


STEP 3 : Output_handle converts the bin files (output) into netcdf format

	Make changes in the following files as mentioned below:

			1. Input folder: input files from test folder of LPJ_runs (STEP 2) and the grid.out files
			
			2. bin2nc_ip.txt: make relevant changes (nlevs, grid_file, input_file and output_file names, base_date, varname and varunit)

			3. Makefile : change libGSM path (and version) and NetCDF path according to location

			4. Go to the Terminal and DO: make clean

				  						  make
			 
				 						  ./bin2nc_lev

			5. Output folder: nc files are obtained for respective variables : Final Output
			
			
			
The STEPS 1-3 are repeated for historical or projection runs in a similar manner. 

                           					
                           					**********REMEMBER TO DO**********

COPY PASTE THE " restart_spin_up.lpj " FILE FROM THE TEST FOLDER OF STEP 2, SPIN UP RUNS INTO THE TEST FOLDER OF STEP2,HISTORICAL RUNS. SIMILARLY, COPY PASTE THE " restart_historical.lpj " FILE FROM THE TEST FOLDER OF STEP 2, HISTORICAL RUNS INTO THE TEST FOLDER OF STEP2, projection RUNS.

















